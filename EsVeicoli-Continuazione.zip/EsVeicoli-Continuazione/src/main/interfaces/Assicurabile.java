package main.interfaces;

import java.math.BigDecimal;

public interface Assicurabile {
    BigDecimal getCostoAssicurazione();
}

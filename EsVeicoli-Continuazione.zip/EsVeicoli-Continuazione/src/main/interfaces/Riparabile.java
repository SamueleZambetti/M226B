package main.interfaces;

import java.math.BigDecimal;

public interface Riparabile {
    BigDecimal calcolaCostoRiparazione(int oreLavoro);

}

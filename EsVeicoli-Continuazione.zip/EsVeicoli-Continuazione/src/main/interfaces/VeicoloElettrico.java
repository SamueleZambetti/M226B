package main.interfaces;

import java.math.BigDecimal;

public interface VeicoloElettrico {
    double getAutonomiaBatteria();
    void ricarica();
}
